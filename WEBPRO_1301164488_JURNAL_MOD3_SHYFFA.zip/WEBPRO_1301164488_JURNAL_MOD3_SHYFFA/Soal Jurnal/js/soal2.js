// write your code here
// tulis kodingan disini

function validasi(){

	var namaMhs = document.getElementById('nama').value;
	var emailMhs = document.getElementById('email').value;
	var alamatMhs = document.getElementById('alamat').value;

	if (namaMhs != "" && emailMhs != "" && alamatMhs != "") {
		alert("Selamat Datang");
	} else {
		alert("Data harus terpenuhi");
	}
}

function ubahBack(){
	document.body.style.backgroundImage = 'url("image.jpg")';
}

function ubahFont(){
	document.getElementById("telkom").style.fontFamily = "Algerian";
}

function sizeFont(){
	document.getElementById("telkom").style.fontSize = "30px";
}

function fontColor(){
	document.getElementById("telkom").style.color = "red";
}

function delate(){
	document.getElementById("telkom").remove();
}
 

